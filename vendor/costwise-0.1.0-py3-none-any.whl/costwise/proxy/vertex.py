"""Google Vertex AI adapter — URL construction, OAuth2 auth, header preparation."""

from __future__ import annotations

import logging
import re
import threading

logger = logging.getLogger(__name__)

try:
    import google.auth
    import google.auth.transport.requests

    _GOOGLE_AUTH_AVAILABLE = True
except ImportError:
    _GOOGLE_AUTH_AVAILABLE = False


_VERTEX_SCOPES = ["https://www.googleapis.com/auth/cloud-platform"]

_DATE_SUFFIX_RE = re.compile(r"-(\d{8})$")


def normalize_model_name(model: str) -> str:
    """Map Anthropic API model names to Vertex AI model names.

    Vertex uses '@' for date-suffixed models (e.g. claude-haiku-4-5@20251001)
    while the Anthropic API uses '-' (claude-haiku-4-5-20251001).
    """
    return _DATE_SUFFIX_RE.sub(r"@\1", model)


def is_available() -> bool:
    return _GOOGLE_AUTH_AVAILABLE


def remap_model(model: str, model_map: dict[str, str]) -> str:
    """Apply configured model remapping (e.g. opus-4-8 → opus-4-6 when unavailable on GCP)."""
    mapped = model_map.get(model)
    if mapped:
        logger.info("Model remap: %s → %s", model, mapped)
        return mapped
    return model


def build_vertex_url(
    region: str,
    project_id: str,
    model: str,
    streaming: bool,
) -> str:
    model = normalize_model_name(model)
    suffix = "streamRawPredict" if streaming else "rawPredict"
    return (
        f"/v1/projects/{project_id}/locations/{region}"
        f"/publishers/anthropic/models/{model}:{suffix}"
    )


def vertex_base_url(region: str) -> str:
    if region == "global":
        return "https://aiplatform.googleapis.com"
    return f"https://{region}-aiplatform.googleapis.com"


def extract_system_messages(body: dict) -> dict:
    """Move system-role messages from the messages array to the top-level system param.

    Some clients (e.g. fullsend code agent) send system content as
    {"role": "system", "content": "..."} inside the messages array.
    The Anthropic API tolerates this, but Vertex AI's rawPredict rejects it
    with a 400. This extracts those messages and merges them into the
    top-level ``system`` parameter that Vertex expects.
    """
    messages = body.get("messages")
    if not messages:
        return body

    system_msgs = [m for m in messages if m.get("role") == "system"]
    if not system_msgs:
        return body

    body["messages"] = [m for m in messages if m.get("role") != "system"]

    extracted_parts: list[str] = []
    for m in system_msgs:
        content = m.get("content", "")
        if isinstance(content, list):
            extracted_parts.extend(
                block.get("text", "") for block in content
                if isinstance(block, dict) and block.get("type") == "text"
            )
        elif isinstance(content, str):
            extracted_parts.append(content)

    if not extracted_parts:
        return body

    new_system = "\n\n".join(extracted_parts)
    existing = body.get("system")
    if existing:
        if isinstance(existing, str):
            body["system"] = existing + "\n\n" + new_system
        elif isinstance(existing, list):
            existing.append({"type": "text", "text": new_system})
    else:
        body["system"] = new_system

    logger.info("Extracted %d system message(s) from messages array", len(system_msgs))
    return body


def prepare_vertex_headers(token: str) -> dict[str, str]:
    return {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
    }


class VertexAuthProvider:
    """Manages Google OAuth2 credentials for Vertex AI.

    Tokens are cached and auto-refreshed when expired (~1 hour lifetime).
    Thread-safe via a lock around refresh operations.
    """

    def __init__(self) -> None:
        if not _GOOGLE_AUTH_AVAILABLE:
            raise ImportError(
                "google-auth is required for Vertex AI support. "
                "Install it with: pip install costwise[vertex]"
            )
        self._lock = threading.Lock()
        self._credentials, self._project = google.auth.default(scopes=_VERTEX_SCOPES)
        self._request = google.auth.transport.requests.Request()

    def get_token(self) -> str:
        with self._lock:
            if not self._credentials.valid:
                self._credentials.refresh(self._request)
            return self._credentials.token

    @property
    def project(self) -> str | None:
        return self._project
