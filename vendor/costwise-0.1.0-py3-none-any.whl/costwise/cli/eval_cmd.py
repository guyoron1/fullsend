"""Offline eval: replay stored signals with different classifier configs."""

from __future__ import annotations

import asyncio
from dataclasses import dataclass

import click

from costwise.config.loader import load_config
from costwise.core.classifier import ClassifierConfig, classify
from costwise.core.models import SignalBundle, Tier
from costwise.core.pricing import PricingRegistry
from costwise.tracking.store import TrackingStore

_PRESETS: dict[str, tuple[float, float]] = {
    "conservative": (0.15, 0.45),
    "default": (0.20, 0.55),
    "aggressive": (0.30, 0.70),
}


@dataclass
class EvalRow:
    """One request's stored signals + actual routing outcome."""

    request_id: int
    actual_tier: str
    actual_model: str | None
    routed_model: str | None
    request_model: str
    prompt_tokens: int
    completion_tokens: int
    cost_usd: float
    saved_usd: float
    was_retried: bool
    signals: SignalBundle


@dataclass
class EvalResult:
    """Aggregated result for one config preset."""

    name: str
    simple_threshold: float
    complex_threshold: float
    total_requests: int
    tier_counts: dict[str, int]
    total_cost_usd: float
    baseline_cost_usd: float
    savings_pct: float
    retry_rate: float
    false_downgrade_count: int
    false_downgrade_rate: float


def _parse_window(window: str) -> int:
    """Parse '7d', '24h', '30d' into hours."""
    window = window.strip().lower()
    if window.endswith("d"):
        return int(window[:-1]) * 24
    if window.endswith("h"):
        return int(window[:-1])
    return int(window)


def _signals_from_row(row: dict) -> SignalBundle:
    """Reconstruct a SignalBundle from a signal_snapshots row."""
    return SignalBundle(
        token_count=row.get("token_count") or 0,
        has_tools=bool(row.get("has_tools")),
        tool_count=row.get("tool_count") or 0,
        has_code=bool(row.get("has_code")),
        code_block_count=row.get("code_block_count") or 0,
        conversation_depth=row.get("conversation_depth") or 0,
        has_error_context=bool(row.get("has_error_context")),
        has_retry_context=bool(row.get("has_retry_context")),
        image_count=row.get("image_count") or 0,
        intent=row.get("intent") or "unknown",
        error_severity=row.get("error_severity") or 0.0,
        multi_file_scope=bool(row.get("multi_file_scope")),
        referenced_file_count=row.get("referenced_file_count") or 0,
        graph_complexity=row.get("graph_complexity") or 0.0,
        ponytail_mode=row.get("ponytail_mode"),
    )


def _estimate_cost(
    registry: PricingRegistry,
    tier: Tier,
    request_model: str,
    prompt_tokens: int,
    completion_tokens: int,
) -> float:
    """Estimate what the cost would be for a given tier assignment."""
    info = registry.cheapest_for_tier(tier) or registry.get(request_model)
    if not info:
        return 0.0
    return (
        prompt_tokens * info.input_cost_per_mtok / 1_000_000
        + completion_tokens * info.output_cost_per_mtok / 1_000_000
    )


def _run_eval(
    rows: list[EvalRow],
    config_name: str,
    simple_threshold: float,
    complex_threshold: float,
    registry: PricingRegistry,
) -> EvalResult:
    """Re-classify every request under a given config and compute metrics."""
    cfg = ClassifierConfig(
        simple_threshold=simple_threshold,
        complex_threshold=complex_threshold,
    )

    tier_counts = {"SIMPLE": 0, "MEDIUM": 0, "COMPLEX": 0}
    total_cost = 0.0
    baseline_cost = 0.0
    false_downgrades = 0
    retried_count = 0

    for row in rows:
        result = classify(row.signals, cfg)
        tier_counts[result.tier.value] += 1

        est = _estimate_cost(
            registry, result.tier,
            row.request_model, row.prompt_tokens, row.completion_tokens,
        )
        total_cost += est

        base = _estimate_cost(
            registry, Tier.COMPLEX,
            row.request_model, row.prompt_tokens, row.completion_tokens,
        )
        baseline_cost += base

        if row.was_retried and result.tier.value != row.actual_tier:
            actual_rank = {"SIMPLE": 0, "MEDIUM": 1, "COMPLEX": 2}.get(row.actual_tier, 0)
            new_rank = {"SIMPLE": 0, "MEDIUM": 1, "COMPLEX": 2}.get(result.tier.value, 0)
            if new_rank < actual_rank:
                false_downgrades += 1

        if row.was_retried:
            retried_count += 1

    savings_pct = (
        (baseline_cost - total_cost) / baseline_cost * 100
        if baseline_cost > 0 else 0.0
    )
    retry_rate = retried_count / len(rows) if rows else 0.0
    downgrade_count = tier_counts["SIMPLE"] + tier_counts["MEDIUM"]
    false_downgrade_rate = (
        false_downgrades / downgrade_count if downgrade_count > 0 else 0.0
    )

    return EvalResult(
        name=config_name,
        simple_threshold=simple_threshold,
        complex_threshold=complex_threshold,
        total_requests=len(rows),
        tier_counts=tier_counts,
        total_cost_usd=total_cost,
        baseline_cost_usd=baseline_cost,
        savings_pct=savings_pct,
        retry_rate=retry_rate,
        false_downgrade_count=false_downgrades,
        false_downgrade_rate=false_downgrade_rate,
    )


def grade_result(result: EvalResult) -> str:
    """Grade an eval result based on savings vs. quality tradeoff.

    TODO: This is a meaningful design decision — see the contribution
    request in the CLI output.

    Current simple heuristic:
      A: savings >= 40% AND false_downgrade_rate < 3%
      B: savings >= 25% AND false_downgrade_rate < 5%
      C: savings >= 10% AND false_downgrade_rate < 10%
      D: savings < 10% OR false_downgrade_rate >= 10%
    """
    s = result.savings_pct
    fdr = result.false_downgrade_rate * 100

    if s >= 40 and fdr < 3:
        return "A"
    if s >= 25 and fdr < 5:
        return "B"
    if s >= 10 and fdr < 10:
        return "C"
    return "D"


def _format_table(results: list[EvalResult]) -> str:
    """Format eval results as a readable table."""
    lines = []
    header = (
        f"{'Config':<14} {'Thresholds':>12} "
        f"{'S/M/C':>10} {'Cost':>9} {'Saved':>7} "
        f"{'FDR':>6} {'Grade':>6}"
    )
    lines.append(header)
    lines.append("─" * len(header))

    for r in results:
        s, m, c = (
            r.tier_counts["SIMPLE"], r.tier_counts["MEDIUM"], r.tier_counts["COMPLEX"],
        )
        tier_dist = f"{s}/{m}/{c}"
        thresholds = f"{r.simple_threshold:.2f}/{r.complex_threshold:.2f}"
        grade = grade_result(r)
        lines.append(
            f"{r.name:<14} {thresholds:>12} "
            f"{tier_dist:>10} ${r.total_cost_usd:>7.2f} {r.savings_pct:>6.1f}% "
            f"{r.false_downgrade_rate * 100:>5.1f}% {grade:>5}"
        )

    return "\n".join(lines)


async def _load_eval_data(store: TrackingStore, window_hours: int) -> list[EvalRow]:
    """Load signal snapshots + routing decisions for the eval window."""
    def _query() -> list[dict]:
        conn = store._get_conn()
        rows = conn.execute(
            """SELECT
                rd.id as request_id,
                rd.tier as actual_tier,
                rd.request_model,
                rd.routed_model,
                rd.prompt_tokens,
                rd.completion_tokens,
                rd.cost_usd,
                rd.saved_usd,
                s.token_count, s.has_tools, s.tool_count,
                s.has_code, s.code_block_count,
                s.conversation_depth, s.has_error_context,
                s.error_severity, s.has_retry_context,
                s.image_count, s.intent,
                s.multi_file_scope, s.referenced_file_count,
                s.graph_complexity, s.ponytail_mode,
                CASE WHEN re.id IS NOT NULL THEN 1 ELSE 0 END as was_retried
            FROM signal_snapshots s
            JOIN routing_decisions rd ON s.request_id = rd.id
            LEFT JOIN retry_events re ON rd.id = re.original_request_id
            WHERE rd.timestamp >= strftime('%Y-%m-%dT%H:%M:%fZ',
                  datetime('now', ? || ' hours'))
            ORDER BY rd.id""",
            (str(-window_hours),),
        ).fetchall()
        return [dict(row) for row in rows]

    raw = await asyncio.to_thread(_query)
    results = []
    for row in raw:
        results.append(EvalRow(
            request_id=row["request_id"],
            actual_tier=row.get("actual_tier") or "COMPLEX",
            actual_model=row.get("routed_model"),
            routed_model=row.get("routed_model"),
            request_model=row.get("request_model") or "claude-opus-4-7",
            prompt_tokens=row.get("prompt_tokens") or 0,
            completion_tokens=row.get("completion_tokens") or 0,
            cost_usd=row.get("cost_usd") or 0.0,
            saved_usd=row.get("saved_usd") or 0.0,
            was_retried=bool(row.get("was_retried")),
            signals=_signals_from_row(row),
        ))
    return results


@click.command("eval")
@click.option(
    "--window", default="7d",
    help="Time window to evaluate (e.g. '7d', '24h', '30d').",
)
@click.option(
    "--configs", default="conservative,default,aggressive,current",
    help="Comma-separated config presets to compare.",
)
@click.option("--json-output", "as_json", is_flag=True, help="Output as JSON.")
def eval_cmd(window: str, configs: str, as_json: bool) -> None:
    """Replay historical routing decisions with different classifier configs."""
    config = load_config()
    store = TrackingStore(config.tracking.db_path)

    window_hours = _parse_window(window)
    config_names = [c.strip() for c in configs.split(",")]

    async def _run() -> list[EvalResult]:
        await store.initialize()
        rows = await _load_eval_data(store, window_hours)

        if not rows:
            click.echo(f"No signal data found in the last {window}.")
            click.echo("Run some requests through the proxy first, then try again.")
            return []

        registry = PricingRegistry()
        results = []

        for name in config_names:
            if name == "current":
                st = config.routing.simple_threshold
                ct = config.routing.complex_threshold
            elif name in _PRESETS:
                st, ct = _PRESETS[name]
            else:
                click.echo(f"Unknown config preset: {name}", err=True)
                continue

            results.append(_run_eval(rows, name, st, ct, registry))

        return results

    results = asyncio.run(_run())
    store.close()

    if not results:
        return

    if as_json:
        import json
        out = []
        for r in results:
            out.append({
                "config": r.name,
                "simple_threshold": r.simple_threshold,
                "complex_threshold": r.complex_threshold,
                "total_requests": r.total_requests,
                "tier_counts": r.tier_counts,
                "total_cost_usd": round(r.total_cost_usd, 4),
                "baseline_cost_usd": round(r.baseline_cost_usd, 4),
                "savings_pct": round(r.savings_pct, 2),
                "retry_rate": round(r.retry_rate, 4),
                "false_downgrade_count": r.false_downgrade_count,
                "false_downgrade_rate": round(r.false_downgrade_rate, 4),
                "grade": grade_result(r),
            })
        click.echo(json.dumps(out, indent=2))
    else:
        n = results[0].total_requests
        click.echo(f"\n╭─ Costwise Eval ({window}, {n} requests) ─╮\n")
        click.echo(_format_table(results))
        click.echo()
