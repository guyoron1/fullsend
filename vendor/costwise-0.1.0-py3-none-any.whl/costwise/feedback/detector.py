"""Retry detector: identifies when a request is a retry of a previously-downgraded request."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from costwise.feedback.fingerprint import extract_user_text, fingerprint, normalize
from costwise.tracking.store import TrackingStore

_TIER_RANK = {"SIMPLE": 0, "MEDIUM": 1, "COMPLEX": 2}


@dataclass(frozen=True)
class RetryEvent:
    session_id: str
    original_request_id: int
    content_hash: str
    similarity_score: float
    original_tier: str
    original_model: str
    time_delta_s: float
    was_downgraded: bool


class RetryDetector:
    def __init__(
        self,
        store: TrackingStore,
        window_minutes: int = 5,
        similarity_threshold: float = 0.7,
    ) -> None:
        self._store = store
        self._window_minutes = window_minutes
        self._similarity_threshold = similarity_threshold

    async def check(
        self,
        session_id: str,
        messages: list[dict],
        content_hash: str | None = None,
    ) -> RetryEvent | None:
        """Check if the current request is a retry of a recently-downgraded request.

        Returns a RetryEvent if a retry is detected, None otherwise.
        """
        if content_hash is None:
            content_hash = fingerprint(messages)

        recent = await self._store.get_recent_fingerprints(
            session_id, window_minutes=self._window_minutes,
        )

        if not recent:
            return None

        current_text = normalize(extract_user_text(messages))
        current_words = set(current_text.split()) if current_text else set()

        best_match: dict | None = None
        best_score = 0.0

        for record in recent:
            stored_hash = record.get("content_hash")
            if not stored_hash:
                continue

            if stored_hash == content_hash:
                score = 1.0
            else:
                stored_text = record.get("normalized_content") or ""
                if not stored_text:
                    continue
                stored_words = set(stored_text.split())
                if not current_words or not stored_words:
                    continue
                intersection = current_words & stored_words
                union = current_words | stored_words
                score = len(intersection) / len(union)

            if score >= self._similarity_threshold and score > best_score:
                best_score = score
                best_match = record

        if best_match is None:
            return None

        routed_model = best_match.get("routed_model")
        if routed_model is None:
            was_downgraded = False
        else:
            routed_tier = best_match.get("tier", "")
            orig_model_tier = best_match.get("request_tier") or routed_tier
            was_downgraded = (
                _TIER_RANK.get(orig_model_tier, 0)
                > _TIER_RANK.get(routed_tier, 0)
            )
        ts_str = best_match.get("timestamp", "")
        try:
            record_time = datetime.fromisoformat(ts_str.replace("Z", "+00:00"))
            now = datetime.now(record_time.tzinfo)
            time_delta = (now - record_time).total_seconds()
        except (ValueError, TypeError):
            time_delta = 0.0

        return RetryEvent(
            session_id=session_id,
            original_request_id=best_match["id"],
            content_hash=content_hash,
            similarity_score=best_score,
            original_tier=best_match.get("tier", ""),
            original_model=best_match.get("request_model", ""),
            time_delta_s=time_delta,
            was_downgraded=was_downgraded,
        )

